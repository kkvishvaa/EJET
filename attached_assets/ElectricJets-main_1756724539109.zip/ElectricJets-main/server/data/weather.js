// Dummy weather data
export default {
  airport: "London Luton (LTN)",
  temperature: 22,
  wind: "8kt NW",
  conditions: "Clear"
};
