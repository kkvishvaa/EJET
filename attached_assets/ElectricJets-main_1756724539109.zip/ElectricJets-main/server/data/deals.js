// Dummy empty legs / last-minute deals dataset
export default [
  {
    id: 1,
    jetId: 1,
    from: "London Luton (LTN)",
    to: "Nice Côte d'Azur (NCE)",
    date: "2025-09-01",
    price: 12000
  },
  {
    id: 2,
    jetId: 2,
    from: "New York Teterboro (TEB)",
    to: "Miami Opa Locka (OPF)",
    date: "2025-09-03",
    price: 18000
  }
];
