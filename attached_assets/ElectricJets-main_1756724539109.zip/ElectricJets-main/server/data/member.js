// Dummy member options
export default {
  types: ["Jet Card", "Single Charter"]
};
