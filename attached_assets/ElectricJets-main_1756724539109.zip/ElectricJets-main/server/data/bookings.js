// Dummy bookings dataset (in-memory)
const bookings = [];

export default {
  bookings,
};
