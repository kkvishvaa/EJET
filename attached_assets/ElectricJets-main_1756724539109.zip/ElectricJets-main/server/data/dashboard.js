// Dummy dashboard metrics
export default {
  users: 120,
  bookings: 45,
  carbonOffset: 3200, // kg CO2
  revenue: 540000,
  emptyLegs: 8
};
